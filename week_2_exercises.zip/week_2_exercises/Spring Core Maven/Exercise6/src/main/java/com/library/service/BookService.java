package com.library.service;

import org.springframework.stereotype.Service;

@Service
public class BookService {

    public void performService() {
        System.out.println("Performing book service...");
    }
}
